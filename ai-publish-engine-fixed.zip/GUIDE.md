# Technical Guide — AI Publish Engine

## Deployment

The application is deployed as a Docker Compose stack with a PostgreSQL database and a Node.js/Express backend serving both the API and static frontend files.

### Server Access

`ash
ssh root@84.247.162.167
`

### Project Location

`ash
/var/www/ai-publish-engine/
`

### Stack

- **Node.js** (Express) — backend API + static file server
- **PostgreSQL** — database (runs in Docker container)
- **Docker Compose** — orchestration
- **Nginx** — reverse proxy (host-level)

---

## PM2 Management

The Node.js app is managed by **PM2** (process manager).

| Action | Command |
|--------|---------|
| Start | pm2 start app.js --name ai-publish-engine |
| Restart | pm2 restart ai-publish-engine |
| Stop | pm2 stop ai-publish-engine |
| Status | pm2 status |
| Logs | pm2 logs ai-publish-engine |
| Monitor | pm2 monit |
| Save | pm2 save |
| Startup | pm2 startup |

PM2 processes persist across reboots when saved via pm2 save.

---

## Nginx Configuration

Nginx serves as a reverse proxy, forwarding requests to the Node.js app.

### Config Location

`ash
/etc/nginx/sites-available/ai-publish-engine
`

### Symlink to enable

`ash
/etc/nginx/sites-enabled/ai-publish-engine
`

### Common commands

`ash
nginx -t                    # test config
systemctl restart nginx     # reload nginx
`

---

## Database — PostgreSQL

The database runs in a Docker container named postgres-db.

### Connection info

| Field | Value |
|-------|-------|
| Host | localhost |
| Port | 5432 |
| Database | ipublish |
| User | ipublish |
| Password | *(in .env file)* |

### Useful commands

`ash
# Connect to PostgreSQL container
docker exec -it postgres-db psql -U aipublish -d aipublish

# List tables
docker exec -it postgres-db psql -U aipublish -d aipublish -c '\dt'

# Backup database
docker exec -t postgres-db pg_dump -U aipublish aipublish > backup.sql

# Restore database
cat backup.sql | docker exec -i postgres-db psql -U aipublish aipublish
`

---

## Logs Location

| Source | Location |
|--------|----------|
| PM2 logs | pm2 logs ai-publish-engine |
| PM2 log files | ~/.pm2/logs/ |
| Nginx access | /var/log/nginx/access.log |
| Nginx error | /var/log/nginx/error.log |
| App output | stdout/stderr (captured by PM2) |

---

## Environment Variables

Configuration is in /var/www/ai-publish-engine/.env.

Key variables:

| Variable | Description |
|----------|-------------|
| DATABASE_URL | PostgreSQL connection string |
| OPENROUTER_API_KEY | API key for OpenRouter |
| GROQ_API_KEY | API key for Groq |
| GEMINI_API_KEY | API key for Gemini |
| OPENAI_API_KEY | API key for OpenAI |
| MISTRAL_API_KEY | API key for Mistral |
| PORT | App port (default: 3000) |
| NODE_ENV | Environment (production / development) |
| JWT_SECRET | Session secret |
| UPLOAD_DIR | Upload directory path |
| MAX_FILE_SIZE | Max upload size in bytes |

---

## Updating the App (Re-deploy)

`ash
cd /var/www/ai-publish-engine

# 1. Pull latest code
git pull origin main

# 2. Install new dependencies
npm install --production

# 3. Run database migrations
npx prisma migrate deploy

# 4. Restart the app
pm2 restart ai-publish-engine

# 5. Verify
pm2 status
`

If Docker containers need updating:

`ash
docker-compose pull
docker-compose up -d
`

---

## Available Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | / | Main page (index.html) |
| GET | /admin | Admin dashboard |
| POST | /api/generate | Generate content (ebook, website, etc.) |
| GET | /api/jobs | List all generation jobs |
| GET | /api/jobs/:id | Get job status |
| POST | /api/jobs/:id/cancel | Cancel a job |
| DELETE | /api/jobs/:id | Delete a job |
| POST | /api/jobs/:id/retry | Retry a failed job |
| GET | /api/jobs/:id/export | Export job result |
| GET | /api/editor/:jobId/chapters | WYSIWYG chapter editor |
| GET | /api/preview/:jobId | Reader preview |
| GET | /api/reader/:jobId | Reader view |
| GET | /api/download/:jobId | File download |
| GET | /api/embed/:jobId | Embeddable book |
| POST | /api/publish/marketing | Generate marketing content |
| POST | /api/publish/translate | Translate content |
| POST | /api/publish/writing-coach | AI Writing Coach |
| POST | /api/publish/proofread | Proofreading + originality check |
| POST | /api/publish/beta-reader | Beta Reader feedback |
| POST | /api/publish/kdp-check | KDP Format Check |
| POST | /api/publish/series | Book Series management |
| POST | /api/publish/launch-page | Book Launch Page |
| POST | /api/publish/print-pdf | Print-ready PDF |
| GET | /api/publish/revenue | Revenue dashboard data |
| POST | /api/templates | List available templates |
