from loguru import logger
from backend.orchestrator.agent import BaseAgent, PipelineContext
from backend.core.ai import generate_design_system as _generate_design_system


class DesignSystemAgent(BaseAgent):
    """Selects or generates visual design tokens for the project."""

    def __init__(self):
        super().__init__("DesignSystemAgent")

    def run(self, ctx: PipelineContext) -> PipelineContext:
        tone = ctx.ebook_dict.get("tone", "professional") if ctx.ebook_dict else "professional"
        ctx.design = _generate_design_system(ctx.style, tone)
        ctx.set_progress(62)
        logger.success(f"DesignSystemAgent: theme={ctx.design.get('theme')}")
        return ctx
