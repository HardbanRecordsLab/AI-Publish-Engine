"""Multi-language publishing — translate + regenerate books in N languages."""
import os
import json
from backend.core.ai import _try_providers
from backend.config import settings

SUPPORTED_LANGUAGES = {
    "en": "English", "pl": "Polish", "de": "German", "fr": "French",
    "es": "Spanish", "it": "Italian", "pt": "Portuguese", "nl": "Dutch",
    "sv": "Swedish", "da": "Danish", "no": "Norwegian", "fi": "Finnish",
    "cs": "Czech", "sk": "Slovak", "hu": "Hungarian", "ro": "Romanian",
    "uk": "Ukrainian", "ru": "Russian", "ar": "Arabic", "he": "Hebrew",
    "tr": "Turkish", "ja": "Japanese", "zh": "Chinese (Simplified)",
    "ko": "Korean", "hi": "Hindi", "th": "Thai", "vi": "Vietnamese",
    "el": "Greek",
}


def _translate_text(text: str, target_lang: str, source_lang: str = "en") -> str:
    system = f"You are a professional translator. Translate from {source_lang} to {target_lang}. Preserve all formatting, markdown, and HTML tags. Return only the translated text."
    user = text
    return _try_providers(system, user, preferred=settings.ai_provider, max_tokens=8000)


def translate_book(ebook_dict: dict, target_lang: str) -> dict:
    """Translate a full ebook_dict into target language."""
    translated = {}
    for key, value in ebook_dict.items():
        if isinstance(value, str) and value.strip():
            translated[key] = _translate_text(value, target_lang)
        elif isinstance(value, list):
            translated[key] = []
            for item in value:
                if isinstance(item, dict):
                    translated[key].append(_translate_dict(item, target_lang))
                elif isinstance(item, str) and item.strip():
                    translated[key].append(_translate_text(item, target_lang))
                else:
                    translated[key] = item
        elif isinstance(value, dict):
            translated[key] = _translate_dict(value, target_lang)
        else:
            translated[key] = value
    return translated


def _translate_dict(d: dict, target_lang: str) -> dict:
    result = {}
    for k, v in d.items():
        if isinstance(v, str) and v.strip():
            result[k] = _translate_text(v, target_lang)
        elif isinstance(v, list):
            result[k] = []
            for item in v:
                if isinstance(item, dict):
                    result[k].append(_translate_dict(item, target_lang))
                elif isinstance(item, str) and item.strip():
                    result[k].append(_translate_text(item, target_lang))
                else:
                    result[k] = item
        elif isinstance(v, dict):
            result[k] = _translate_dict(v, target_lang)
        else:
            result[k] = v
    return result
