from fastapi import APIRouter, Response, Depends
from fastapi.responses import JSONResponse, HTMLResponse

from backend.core.jobs import get_all_jobs, get_job, delete_job, update_job
from backend.routers.auth import require_admin

router = APIRouter()


@router.get("/api/admin/jobs", dependencies=[Depends(require_admin)])
def admin_list_jobs():
    jobs = get_all_jobs()
    return [{
        "id": j["id"],
        "status": j["status"],
        "progress": j["progress"],
        "topic": j.get("topic", ""),
        "style": j.get("style", ""),
        "content_type": j.get("content_type", ""),
        "created_at": str(j.get("created_at", "")),
    } for j in jobs]


@router.delete("/api/admin/jobs/{job_id}", dependencies=[Depends(require_admin)])
def admin_delete_job(job_id: str):
    delete_job(job_id)
    return {"status": "deleted"}


@router.post("/api/admin/jobs/{job_id}/retry", dependencies=[Depends(require_admin)])
def admin_retry_job(job_id: str):
    job = get_job(job_id)
    if not job:
        return JSONResponse({"error": "Job not found"}, status_code=404)
    if job["status"] != "done":
        update_job(job_id, "queued", 0, error="")
    return {"status": "retrying"}


@router.get("/api/admin/jobs/export", dependencies=[Depends(require_admin)])
def admin_export_csv():
    jobs = get_all_jobs()
    import csv
    from io import StringIO
    output = StringIO()
    w = csv.writer(output)
    w.writerow(["id", "status", "progress", "topic", "style", "content_type", "created_at"])
    for j in jobs:
        w.writerow([j.get("id", ""), j.get("status", ""), j.get("progress", 0),
                    j.get("topic", ""), j.get("style", ""), j.get("content_type", ""),
                    str(j.get("created_at", ""))])
    return Response(content=output.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=ai_publish_jobs.csv"})
