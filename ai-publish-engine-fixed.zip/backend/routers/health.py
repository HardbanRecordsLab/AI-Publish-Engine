import time
from datetime import datetime
from fastapi import APIRouter
from backend.core.ai import PROVIDERS

router = APIRouter()

START_TIME = time.time()


@router.get("/api/health")
def health():
    uptime = time.time() - START_TIME
    return {
        "status": "ok",
        "uptime_seconds": round(uptime),
        "timestamp": datetime.now().isoformat(),
        "version": "2.0.0",
    }


@router.get("/api/providers")
def get_providers():
    return [
        {"id": k, "model": v["model"], "site": v["site"], "env_var": v["api_key_env"]}
        for k, v in PROVIDERS.items()
    ]
