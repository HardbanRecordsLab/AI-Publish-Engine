"""Theme registry — 20 professional design themes.
Each theme defines complete design tokens for the AI Design Engine."""

THEMES = {
    "business": {
        "id": "business", "name": "Business Pro", "vibe": "professional authoritative",
        "colors": {
            "background": "#FFFFFF", "surface": "#F8FAFC", "text": "#1E293B",
            "heading": "#0F172A", "accent": "#1D4ED8", "secondary": "#EFF6FF",
            "muted": "#64748B", "border": "#CBD5E1", "highlight": "#F0F4FF",
            "success": "#22C55E", "warning": "#F59E0B", "error": "#EF4444", "info": "#3B82F6",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "40pt", "h2": "24pt", "h3": "16pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0F172A 0%, #1E3A5F 50%, #1D4ED8 100%)",
        "accent_gradient": "linear-gradient(135deg, #1D4ED8 0%, #2563EB 100%)",
        "cover_icon": "mdi:briefcase",
    },
    "dark": {
        "id": "dark", "name": "Dark Premium", "vibe": "modern premium",
        "colors": {
            "background": "#0B0F1A", "surface": "#111827", "text": "#E2E8F0",
            "heading": "#F1F5F9", "accent": "#00E5FF", "secondary": "#1E293B",
            "muted": "#475569", "border": "#1E293B", "highlight": "#1A1F2E",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#06B6D4",
        },
        "fonts": {"heading": "'Inter', -apple-system, sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "42pt", "h2": "26pt", "h3": "17pt", "body": "10.5pt"},
        "cover_gradient": "radial-gradient(ellipse at 50% 0%, #1A1F2E 0%, #0B0F1A 70%)",
        "accent_gradient": "linear-gradient(135deg, #00E5FF 0%, #7C4DFF 100%)",
        "cover_icon": "mdi:weather-night",
    },
    "ai": {
        "id": "ai", "name": "AI & Tech", "vibe": "futuristic innovative",
        "colors": {
            "background": "#F5F3FF", "surface": "#EDE9FE", "text": "#1A1A2E",
            "heading": "#0B0F1A", "accent": "#7C4DFF", "secondary": "#F3E8FF",
            "muted": "#6B7280", "border": "#DDD6FE", "highlight": "#FAF5FF",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#7C4DFF",
        },
        "fonts": {"heading": "'Inter', -apple-system, sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "40pt", "h2": "24pt", "h3": "16pt", "body": "10pt"},
        "cover_gradient": "linear-gradient(135deg, #0B0F1A 0%, #2D1B69 50%, #7C4DFF 100%)",
        "accent_gradient": "linear-gradient(135deg, #7C4DFF 0%, #A855F7 100%)",
        "cover_icon": "mdi:robot",
    },
    "finance": {
        "id": "finance", "name": "Financial", "vibe": "premium authoritative",
        "colors": {
            "background": "#FDFBF7", "surface": "#F5F0E8", "text": "#1C1C1C",
            "heading": "#1A1A2E", "accent": "#B8860B", "secondary": "#F5F0E8",
            "muted": "#8B7355", "border": "#D4C5A9", "highlight": "#FAF6EF",
            "success": "#059669", "warning": "#D97706", "error": "#DC2626", "info": "#2563EB",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "38pt", "h2": "22pt", "h3": "15pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #1A1A2E 0%, #2D2D44 50%, #B8860B 100%)",
        "accent_gradient": "linear-gradient(135deg, #B8860B 0%, #DAA520 100%)",
        "cover_icon": "mdi:chart-line",
    },
    "health": {
        "id": "health", "name": "Health & Wellness", "vibe": "fresh natural",
        "colors": {
            "background": "#F8FAF5", "surface": "#F0FDF4", "text": "#1A2E1A",
            "heading": "#0F1F0F", "accent": "#22C55E", "secondary": "#F0FDF4",
            "muted": "#6B8E6B", "border": "#BBE8BB", "highlight": "#F0FFF4",
            "success": "#16A34A", "warning": "#F97316", "error": "#DC2626", "info": "#06B6D4",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "38pt", "h2": "22pt", "h3": "15pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0F1F0F 0%, #1A3A1A 50%, #22C55E 100%)",
        "accent_gradient": "linear-gradient(135deg, #22C55E 0%, #16A34A 100%)",
        "cover_icon": "mdi:heart-pulse",
    },
    "luxury": {
        "id": "luxury", "name": "Luxury", "vibe": "elegant exclusive",
        "colors": {
            "background": "#FDFCFB", "surface": "#F8F6F3", "text": "#1A1A1A",
            "heading": "#0A0A0A", "accent": "#C4956A", "secondary": "#F5F0EB",
            "muted": "#8C8C8C", "border": "#E5DDD5", "highlight": "#FAF7F3",
            "success": "#2D6A4F", "warning": "#C4956A", "error": "#9B2226", "info": "#6B705C",
        },
        "fonts": {"heading": "'Playfair Display', 'Georgia', serif", "body": "'Lato', 'Helvetica Neue', sans-serif"},
        "font_sizes": {"h1": "44pt", "h2": "26pt", "h3": "17pt", "body": "11pt"},
        "cover_gradient": "linear-gradient(135deg, #0A0A0A 0%, #2D2D2D 50%, #C4956A 100%)",
        "accent_gradient": "linear-gradient(135deg, #C4956A 0%, #D4A574 100%)",
        "cover_icon": "mdi:diamond",
    },
    "magazine": {
        "id": "magazine", "name": "Magazine", "vibe": "dynamic editorial",
        "colors": {
            "background": "#FFFFFF", "surface": "#F5F5F5", "text": "#222222",
            "heading": "#111111", "accent": "#E11D48", "secondary": "#FFF1F2",
            "muted": "#71717A", "border": "#E4E4E7", "highlight": "#FAFAFA",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#3B82F6",
        },
        "fonts": {"heading": "'Poppins', 'Helvetica Neue', sans-serif", "body": "'Merriweather', 'Georgia', serif"},
        "font_sizes": {"h1": "44pt", "h2": "28pt", "h3": "18pt", "body": "10pt"},
        "cover_gradient": "linear-gradient(135deg, #111111 0%, #E11D48 50%, #BE123C 100%)",
        "accent_gradient": "linear-gradient(135deg, #E11D48 0%, #BE123C 100%)",
        "cover_icon": "mdi:fire",
    },
    "corporate": {
        "id": "corporate", "name": "Corporate Pro", "vibe": "structured professional",
        "colors": {
            "background": "#FFFFFF", "surface": "#F8FAFC", "text": "#1E2A3A",
            "heading": "#0F172A", "accent": "#2563EB", "secondary": "#F0F4FF",
            "muted": "#64748B", "border": "#CBD5E1", "highlight": "#EFF6FF",
            "success": "#22C55E", "warning": "#F59E0B", "error": "#EF4444", "info": "#3B82F6",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "40pt", "h2": "24pt", "h3": "16pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0F172A 0%, #1E40AF 50%, #2563EB 100%)",
        "accent_gradient": "linear-gradient(135deg, #2563EB 0%, #1D4ED8 100%)",
        "cover_icon": "mdi:office-building",
    },
    "minimal": {
        "id": "minimal", "name": "Minimal Pro", "vibe": "clean minimal",
        "colors": {
            "background": "#FFFFFF", "surface": "#FAFAFA", "text": "#1A1A1A",
            "heading": "#000000", "accent": "#4A4A4A", "secondary": "#F5F5F5",
            "muted": "#999999", "border": "#E5E5E5", "highlight": "#F0F0F0",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#3B82F6",
        },
        "fonts": {"heading": "'Inter', -apple-system, sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "38pt", "h2": "22pt", "h3": "15pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #FAFAFA 0%, #FFFFFF 100%)",
        "accent_gradient": "linear-gradient(135deg, #4A4A4A 0%, #6A6A6A 100%)",
        "cover_icon": "mdi:book",
    },
    "book": {
        "id": "book", "name": "Classic Book", "vibe": "timeless traditional",
        "colors": {
            "background": "#FDF8F0", "surface": "#FAF5EB", "text": "#2D2D2D",
            "heading": "#1A1A1A", "accent": "#8B4513", "secondary": "#F5EDE0",
            "muted": "#6B6B6B", "border": "#D4C5A9", "highlight": "#F5EDE0",
            "success": "#2D6A4F", "warning": "#8B4513", "error": "#9B2226", "info": "#5C4033",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Palatino', 'Georgia', serif"},
        "font_sizes": {"h1": "36pt", "h2": "20pt", "h3": "14pt", "body": "11pt"},
        "cover_gradient": "linear-gradient(135deg, #1A1A1A 0%, #3D2B1F 50%, #8B4513 100%)",
        "accent_gradient": "linear-gradient(135deg, #8B4513 0%, #A0522D 100%)",
        "cover_icon": "mdi:book-open-page-variant",
    },
    "story": {
        "id": "story", "name": "Storyteller", "vibe": "narrative warm",
        "colors": {
            "background": "#FEFCF6", "surface": "#FFF9F0", "text": "#2C1810",
            "heading": "#1A0F0A", "accent": "#D97706", "secondary": "#FFFBEB",
            "muted": "#92400E", "border": "#FDE68A", "highlight": "#FFF9F0",
            "success": "#059669", "warning": "#D97706", "error": "#DC2626", "info": "#6366F1",
        },
        "fonts": {"heading": "'Merriweather', 'Georgia', serif", "body": "'Merriweather', 'Georgia', serif"},
        "font_sizes": {"h1": "36pt", "h2": "20pt", "h3": "14pt", "body": "11pt"},
        "cover_gradient": "linear-gradient(135deg, #1A0F0A 0%, #3D2B1F 50%, #D97706 100%)",
        "accent_gradient": "linear-gradient(135deg, #D97706 0%, #F59E0B 100%)",
        "cover_icon": "mdi:feather",
    },
    "education": {
        "id": "education", "name": "Education", "vibe": "engaging academic",
        "colors": {
            "background": "#FAFAFA", "surface": "#EEF2FF", "text": "#1E293B",
            "heading": "#0F172A", "accent": "#6366F1", "secondary": "#EEF2FF",
            "muted": "#94A3B8", "border": "#C7D2FE", "highlight": "#F0F0FF",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#6366F1",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "38pt", "h2": "22pt", "h3": "15pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0F172A 0%, #312E81 50%, #6366F1 100%)",
        "accent_gradient": "linear-gradient(135deg, #6366F1 0%, #818CF8 100%)",
        "cover_icon": "mdi:school",
    },
    "cookbook": {
        "id": "cookbook", "name": "Cookbook", "vibe": "warm inviting",
        "colors": {
            "background": "#FFFCF5", "surface": "#FFF7ED", "text": "#1C1917",
            "heading": "#0C0A09", "accent": "#EA580C", "secondary": "#FFF7ED",
            "muted": "#A8A29E", "border": "#E7E5E4", "highlight": "#FFF9F0",
            "success": "#22C55E", "warning": "#EA580C", "error": "#DC2626", "info": "#3B82F6",
        },
        "fonts": {"heading": "'Playfair Display', 'Georgia', serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "36pt", "h2": "22pt", "h3": "15pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0C0A09 0%, #431407 50%, #EA580C 100%)",
        "accent_gradient": "linear-gradient(135deg, #EA580C 0%, #F97316 100%)",
        "cover_icon": "mdi:silverware-fork-knife",
    },
    "travel": {
        "id": "travel", "name": "Travel", "vibe": "adventurous vibrant",
        "colors": {
            "background": "#F8FAFC", "surface": "#ECFEFF", "text": "#1E293B",
            "heading": "#0F172A", "accent": "#0891B2", "secondary": "#ECFEFF",
            "muted": "#64748B", "border": "#CFFAFE", "highlight": "#F0F9FF",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#0891B2",
        },
        "fonts": {"heading": "'Poppins', 'Helvetica Neue', sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "40pt", "h2": "24pt", "h3": "16pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0F172A 0%, #065F73 50%, #0891B2 100%)",
        "accent_gradient": "linear-gradient(135deg, #0891B2 0%, #06B6D4 100%)",
        "cover_icon": "mdi:compass",
    },
    "real_estate": {
        "id": "real_estate", "name": "Real Estate", "vibe": "sophisticated premium",
        "colors": {
            "background": "#FCFCFA", "surface": "#F5F5F0", "text": "#1C1C1C",
            "heading": "#0A0A0A", "accent": "#1E3A5F", "secondary": "#F0F4F8",
            "muted": "#6B7280", "border": "#D1D5DB", "highlight": "#F9FAFB",
            "success": "#059669", "warning": "#D97706", "error": "#DC2626", "info": "#2563EB",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "40pt", "h2": "24pt", "h3": "16pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0A0A0A 0%, #1E3A5F 50%, #2E5A8F 100%)",
        "accent_gradient": "linear-gradient(135deg, #1E3A5F 0%, #2E5A8F 100%)",
        "cover_icon": "mdi:home-city",
    },
    "music": {
        "id": "music", "name": "Music", "vibe": "creative dynamic",
        "colors": {
            "background": "#0F0F1A", "surface": "#1A1A2E", "text": "#E2E8F0",
            "heading": "#F1F5F9", "accent": "#EC4899", "secondary": "#2D1B3D",
            "muted": "#6B7280", "border": "#2D1B69", "highlight": "#1A1A2E",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#8B5CF6",
        },
        "fonts": {"heading": "'Poppins', 'Helvetica Neue', sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "42pt", "h2": "26pt", "h3": "17pt", "body": "10pt"},
        "cover_gradient": "linear-gradient(135deg, #0F0F1A 0%, #2D1B3D 50%, #EC4899 100%)",
        "accent_gradient": "linear-gradient(135deg, #EC4899 0%, #BE185D 100%)",
        "cover_icon": "mdi:music-note",
    },
    "startup": {
        "id": "startup", "name": "Startup", "vibe": "bold modern",
        "colors": {
            "background": "#FFFFFF", "surface": "#F5F5F5", "text": "#0F172A",
            "heading": "#020617", "accent": "#F59E0B", "secondary": "#FFFBEB",
            "muted": "#6B7280", "border": "#E5E7EB", "highlight": "#FEFCE8",
            "success": "#22C55E", "warning": "#F59E0B", "error": "#EF4444", "info": "#3B82F6",
        },
        "fonts": {"heading": "'Inter', -apple-system, sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "42pt", "h2": "26pt", "h3": "17pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #020617 0%, #1E293B 50%, #F59E0B 100%)",
        "accent_gradient": "linear-gradient(135deg, #F59E0B 0%, #F97316 100%)",
        "cover_icon": "mdi:rocket-launch",
    },
    "cyberpunk": {
        "id": "cyberpunk", "name": "Cyberpunk", "vibe": "edgy futuristic",
        "colors": {
            "background": "#0A0A0F", "surface": "#141428", "text": "#E2E8F0",
            "heading": "#F1F5F9", "accent": "#FF006E", "secondary": "#1A0A2E",
            "muted": "#6B7280", "border": "#2D1B69", "highlight": "#1A0A2E",
            "success": "#00FF9D", "warning": "#FFBE0B", "error": "#FF006E", "info": "#00E5FF",
        },
        "fonts": {"heading": "'Poppins', 'Helvetica Neue', sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "44pt", "h2": "28pt", "h3": "18pt", "body": "10pt"},
        "cover_gradient": "linear-gradient(135deg, #0A0A0F 0%, #1A0A2E 50%, #FF006E 100%)",
        "accent_gradient": "linear-gradient(135deg, #FF006E 0%, #00E5FF 100%)",
        "cover_icon": "mdi:lightning-bolt",
    },
    "retro": {
        "id": "retro", "name": "Retro Vintage", "vibe": "warm nostalgic",
        "colors": {
            "background": "#FDF5E6", "surface": "#FAF0E6", "text": "#3D2B1F",
            "heading": "#1A0F0A", "accent": "#C85A17", "secondary": "#F5DEB3",
            "muted": "#8B7355", "border": "#DEB887", "highlight": "#FAEBD7",
            "success": "#556B2F", "warning": "#C85A17", "error": "#8B0000", "info": "#4682B4",
        },
        "fonts": {"heading": "'Playfair Display', 'Georgia', serif", "body": "'Lora', 'Georgia', serif"},
        "font_sizes": {"h1": "36pt", "h2": "20pt", "h3": "14pt", "body": "11pt"},
        "cover_gradient": "linear-gradient(135deg, #1A0F0A 0%, #5C3317 50%, #C85A17 100%)",
        "accent_gradient": "linear-gradient(135deg, #C85A17 0%, #D2691E 100%)",
        "cover_icon": "mdi:record-player",
    },
    "future": {
        "id": "future", "name": "Future Forward", "vibe": "clean tech-forward",
        "colors": {
            "background": "#F0F9FF", "surface": "#E6F7FF", "text": "#0F172A",
            "heading": "#020617", "accent": "#06B6D4", "secondary": "#ECFEFF",
            "muted": "#64748B", "border": "#CFFAFE", "highlight": "#F0F9FF",
            "success": "#22C55E", "warning": "#F59E0B", "error": "#EF4444", "info": "#06B6D4",
        },
        "fonts": {"heading": "'Inter', -apple-system, sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "40pt", "h2": "24pt", "h3": "16pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #020617 0%, #0F172A 50%, #06B6D4 100%)",
        "accent_gradient": "linear-gradient(135deg, #06B6D4 0%, #3B82F6 100%)",
        "cover_icon": "mdi:wave",
    },
    "modern": {
        "id": "modern", "name": "Modern", "vibe": "contemporary clean",
        "colors": {
            "background": "#FAFAFA", "surface": "#FFFFFF", "text": "#1A1A2E",
            "heading": "#0F0F1A", "accent": "#6366F1", "secondary": "#EEF2FF",
            "muted": "#6B7280", "border": "#E5E7EB", "highlight": "#F5F7FF",
            "success": "#22C55E", "warning": "#F59E0B", "error": "#EF4444", "info": "#3B82F6",
        },
        "fonts": {"heading": "'Inter', -apple-system, sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "40pt", "h2": "24pt", "h3": "16pt", "body": "10.5pt"},
        "cover_gradient": "linear-gradient(135deg, #0F0F1A 0%, #1A1A2E 50%, #6366F1 100%)",
        "accent_gradient": "linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)",
        "cover_icon": "mdi:palette-swatch",
    },
    "academic": {
        "id": "academic", "name": "Academic", "vibe": "formal scholarly",
        "colors": {
            "background": "#FCFAF5", "surface": "#F8F6F0", "text": "#2D2D2D",
            "heading": "#1A1A1A", "accent": "#8B0000", "secondary": "#F5F0EB",
            "muted": "#6B6B6B", "border": "#D4C5A9", "highlight": "#F5F0EB",
            "success": "#2D6A4F", "warning": "#8B4513", "error": "#9B2226", "info": "#1E3A5F",
        },
        "fonts": {"heading": "'Georgia', 'Times New Roman', serif", "body": "'Georgia', 'Times New Roman', serif"},
        "font_sizes": {"h1": "36pt", "h2": "20pt", "h3": "14pt", "body": "11pt"},
        "cover_gradient": "linear-gradient(135deg, #1A1A1A 0%, #3D2B1F 50%, #8B0000 100%)",
        "accent_gradient": "linear-gradient(135deg, #8B0000 0%, #A52A2A 100%)",
        "cover_icon": "mdi:school",
    },
    "creative": {
        "id": "creative", "name": "Creative", "vibe": "bold artistic",
        "colors": {
            "background": "#FDFBFF", "surface": "#F8F5FF", "text": "#1A1A2E",
            "heading": "#0B0F1A", "accent": "#A855F7", "secondary": "#F3E8FF",
            "muted": "#7C6B8E", "border": "#E5D9F2", "highlight": "#FAF5FF",
            "success": "#22C55E", "warning": "#F97316", "error": "#EF4444", "info": "#8B5CF6",
        },
        "fonts": {"heading": "'Poppins', 'Helvetica Neue', sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "42pt", "h2": "26pt", "h3": "17pt", "body": "10pt"},
        "cover_gradient": "linear-gradient(135deg, #0B0F1A 0%, #3B1F6E 50%, #A855F7 100%)",
        "accent_gradient": "linear-gradient(135deg, #A855F7 0%, #D946EF 100%)",
        "cover_icon": "mdi:palette",
    },
    "technical": {
        "id": "technical", "name": "Technical", "vibe": "precise clear",
        "colors": {
            "background": "#FAFCFF", "surface": "#F0F7FF", "text": "#1E293B",
            "heading": "#0F172A", "accent": "#0EA5E9", "secondary": "#E0F2FE",
            "muted": "#64748B", "border": "#BAE6FD", "highlight": "#F0F9FF",
            "success": "#22C55E", "warning": "#F59E0B", "error": "#EF4444", "info": "#0EA5E9",
        },
        "fonts": {"heading": "'Inter', -apple-system, sans-serif", "body": "'Inter', -apple-system, sans-serif"},
        "font_sizes": {"h1": "38pt", "h2": "22pt", "h3": "15pt", "body": "10pt"},
        "cover_gradient": "linear-gradient(135deg, #0F172A 0%, #0C4A6E 50%, #0EA5E9 100%)",
        "accent_gradient": "linear-gradient(135deg, #0EA5E9 0%, #38BDF8 100%)",
        "cover_icon": "mdi:cog",
    },
    "wellness": {
        "id": "wellness", "name": "Wellness", "vibe": "calm harmonious",
        "colors": {
            "background": "#F8FAF5", "surface": "#F0FDF4", "text": "#1A2E1A",
            "heading": "#0F1F0F", "accent": "#22C55E", "secondary": "#DCFCE7",
            "muted": "#6B8E6B", "border": "#BBE8BB", "highlight": "#F0FFF4",
            "success": "#16A34A", "warning": "#F97316", "error": "#DC2626", "info": "#06B6D4",
        },
        "fonts": {"heading": "'Merriweather', 'Georgia', serif", "body": "'Lato', 'Helvetica Neue', sans-serif"},
        "font_sizes": {"h1": "36pt", "h2": "20pt", "h3": "14pt", "body": "11pt"},
        "cover_gradient": "linear-gradient(135deg, #0F1F0F 0%, #1A3A1A 50%, #22C55E 100%)",
        "accent_gradient": "linear-gradient(135deg, #22C55E 0%, #16A34A 100%)",
        "cover_icon": "mdi:leaf",
    },
}

# Shared design tokens (all themes)
SPACING = {
    "xs": "0.25rem", "sm": "0.5rem", "md": "1rem", "lg": "1.5rem",
    "xl": "2rem", "2xl": "3rem", "3xl": "4rem",
}
RADII = {"sm": "4px", "md": "8px", "lg": "12px", "xl": "16px"}
SHADOWS = {"sm": "0 1px 2px rgba(0,0,0,0.05)", "md": "0 4px 6px rgba(0,0,0,0.07)", "lg": "0 10px 15px rgba(0,0,0,0.1)"}
PAGE = {
    "format": "A4", "margin_top": "2.2cm", "margin_bottom": "2.5cm",
    "margin_left": "2cm", "margin_right": "2cm",
    "footer_font_size": "7pt", "line_height": 1.75,
    "content_width": "14cm",
}


def get_theme(theme_id: str) -> dict:
    """Get complete theme with defaults applied."""
    base = THEMES.get(theme_id, THEMES["minimal"])
    return {
        **base,
        "spacing": SPACING,
        "radii": RADII,
        "shadows": SHADOWS,
        "page": PAGE,
        "custom_css": "",
    }


def list_themes() -> list[dict]:
    """List all themes for frontend display."""
    return [
        {"id": t["id"], "name": t["name"], "vibe": t["vibe"],
         "colors": t["colors"], "cover_icon": t["cover_icon"]}
        for t in THEMES.values()
    ]


def generate_theme_css(theme_id: str) -> str:
    """Generate complete CSS with design tokens for a theme."""
    t = get_theme(theme_id)
    cols = t["colors"]
    return f"""/* {t['name']} — {t['vibe']} */
:root {{
  --color-bg: {cols['background']};
  --color-surface: {cols['surface']};
  --color-text: {cols['text']};
  --color-heading: {cols['heading']};
  --color-accent: {cols['accent']};
  --color-secondary: {cols['secondary']};
  --color-muted: {cols['muted']};
  --color-border: {cols['border']};
  --color-highlight: {cols['highlight']};
  --color-success: {cols['success']};
  --color-warning: {cols['warning']};
  --color-error: {cols['error']};
  --color-info: {cols['info']};
  --font-heading: {t['fonts']['heading']};
  --font-body: {t['fonts']['body']};
  --font-size-h1: {t['font_sizes']['h1']};
  --font-size-h2: {t['font_sizes']['h2']};
  --font-size-h3: {t['font_sizes']['h3']};
  --font-size-body: {t['font_sizes']['body']};
  --cover-gradient: {t['cover_gradient']};
  --accent-gradient: {t['accent_gradient']};
}}"""
